﻿//IPZ11 ПІБ студента lab3 вар. ...
#include<iostream>
using namespace std;
int main()
{
//код програми л.р. 3

}