﻿//IPZ11 ПІБ студента lab2 вар. ...
#include<iostream>
using namespace std;
int main()
{
//код програми л.р. 2

}
